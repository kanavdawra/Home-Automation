<?php

include('connect.php');

    header("Refresh:0; url=dashboard.php");

$conn->close();
?>